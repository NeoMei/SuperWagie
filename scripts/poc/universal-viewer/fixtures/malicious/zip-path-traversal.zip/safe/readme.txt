Metadata-only traversal fixture.
